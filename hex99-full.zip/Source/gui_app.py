import os
import sys
import re
import json
import logging
import requests
from bs4 import BeautifulSoup

from PyQt5.QtCore import Qt, QThread, pyqtSignal, QUrl
from PyQt5.QtGui import QFont, QIcon, QColor, QDesktopServices
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QLabel, QTabWidget, QTableWidget,
    QTableWidgetItem, QHeaderView, QTextEdit, QFrame, QSplitter,
    QMessageBox, QListWidget, QProgressBar, QGridLayout, QSizePolicy
)

# Standard headers to bypass CFX rate limits / blocks
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5'
}

def clean_fivem_colors(text):
    if not text:
        return ""
    # Strip standard FiveM caret color sequences (^0 to ^9, ^r, etc.)
    return re.sub(r'\^[0-9;r]', '', text).strip()

def fivem_to_html(text):
    if not text:
        return ""
    colors = {
        '1': '#f43f3f', # Red
        '2': '#22c55e', # Green
        '3': '#eab308', # Yellow
        '4': '#3b82f6', # Blue
        '5': '#06b6d4', # Light Blue
        '6': '#a855f7', # Purple
        '7': '#ffffff', # White
        '8': '#ef4444', # Dark Red
        '9': '#ec4899', # Pink
        '0': '#ffffff', # White
    }
    
    parts = re.split(r'(\^[0-9;r])', text)
    current_color = '#ffffff'
    html = ""
    for part in parts:
        if part.startswith('^') and len(part) >= 2:
            code = part[1]
            if code in colors:
                current_color = colors[code]
            elif code in ('r', ';'):
                current_color = '#ffffff'
        else:
            if part:
                safe_part = part.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                html += f'<span style="color: {current_color};">{safe_part}</span>'
    return html

def extract_cfx_code(input_str):
    if not input_str:
        return None
    input_str = input_str.strip()
    match = re.search(r'(?:join\/|cfx\.re\/join\/)?([a-zA-Z0-9_-]+)', input_str)
    if match:
        extracted = match.group(1)
        if '?' in extracted:
            extracted = extracted.split('?')[0]
        return extracted
    return input_str if input_str else None

# Background Worker Thread for non-blocking HTTP network resolution
class ResolverThread(QThread):
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)
    status_update = pyqtSignal(str)

    def __init__(self, raw_input):
        super().__init__()
        self.raw_input = raw_input

    def run(self):
        code = extract_cfx_code(self.raw_input)
        if not code:
            self.error.emit("Invalid CFX Code! Please enter a valid 6-character code or cfx.re join link.")
            return

        self.status_update.emit(f"Connecting to Cfx.re Master API for code: {code}...")
        
        # --- Approach A: Master Frontend API ---
        master_api_url = f"https://frontend.cfx-services.net/api/servers/single/{code}"
        try:
            res = requests.get(master_api_url, headers=HEADERS, timeout=6)
            if res.status_code == 200:
                data = res.json().get('Data', {})
                endpoints = data.get('connectEndPoints', [])
                endpoint = endpoints[0] if endpoints else "Hidden / Protected"

                result = {
                    'code': code,
                    'endpoint': endpoint,
                    'hostname': data.get('hostname', 'Unknown Server'),
                    'clients': data.get('clients', 0),
                    'sv_maxclients': data.get('sv_maxclients', 32),
                    'gametype': data.get('gametype', 'Roleplay'),
                    'mapname': data.get('mapname', 'San Andreas'),
                    'gamebuild': data.get('vars', {}).get('sv_enforceGameBuild', 'Default'),
                    'onesync': data.get('vars', {}).get('onesync_enabled', 'false'),
                    'server_version': data.get('server', 'FXServer-master'),
                    'owner_name': data.get('ownerName', 'Unknown'),
                    'owner_profile': data.get('ownerProfile', ''),
                    'upvote_power': data.get('upvotePower', 0),
                    'players': data.get('players', []),
                    'resources': data.get('resources', []),
                    'vars': data.get('vars', {}),
                    'raw': data
                }
                self.finished.emit(result)
                return
        except Exception as e:
            self.status_update.emit(f"Master API failed: {e}. Trying Fallback join resolver...")

        # --- Approach B: Fallback Scraper ---
        try:
            join_url = f"https://cfx.re/join/{code}"
            res = requests.get(join_url, headers=HEADERS, timeout=6)
            if res.status_code == 404:
                self.error.emit(f"Server ({code}) not found or offline.")
                return

            endpoint = res.headers.get('x-citizenfx-url', 'Unknown')
            soup = BeautifulSoup(res.text, 'html.parser')
            title = soup.find('title')
            hostname = title.text.strip().replace(' / Cfx.re', '') if title else code

            players_list = []
            resources_list = []
            vars_dict = {}

            if endpoint and endpoint.startswith('http'):
                clean_ep = endpoint.rstrip('/') + '/'
                try:
                    info_res = requests.get(f"{clean_ep}info.json", headers=HEADERS, timeout=3)
                    if info_res.status_code == 200:
                        info_data = info_res.json()
                        resources_list = info_data.get('resources', [])
                        vars_dict = info_data.get('vars', {})
                except Exception:
                    pass

                try:
                    p_res = requests.get(f"{clean_ep}players.json", headers=HEADERS, timeout=3)
                    if p_res.status_code == 200:
                        players_list = p_res.json()
                except Exception:
                    pass

            result = {
                'code': code,
                'endpoint': endpoint,
                'hostname': hostname,
                'clients': len(players_list),
                'sv_maxclients': vars_dict.get('sv_maxclients', 32),
                'gametype': vars_dict.get('gametype', 'Roleplay'),
                'mapname': vars_dict.get('mapname', 'San Andreas'),
                'gamebuild': vars_dict.get('sv_enforceGameBuild', 'Default'),
                'onesync': vars_dict.get('onesync_enabled', 'Unknown'),
                'server_version': vars_dict.get('server', 'FXServer'),
                'owner_name': 'Unknown',
                'owner_profile': '',
                'upvote_power': 0,
                'players': players_list,
                'resources': resources_list,
                'vars': vars_dict,
                'raw': {'info': vars_dict, 'players': players_list}
            }
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(f"Connection error: {str(e)}")

# Modern Cyberpunk Stylesheet
DARK_STYLESHEET = """
QMainWindow {
    background-color: #0a0a0c;
}
QWidget {
    background-color: #0a0a0c;
    color: #e6e6e9;
    font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
    font-size: 13px;
}
QFrame#card {
    background-color: #111114;
    border: 1px solid #26262b;
    border-radius: 8px;
}
QFrame#accentCard {
    background-color: #141419;
    border: 1px solid #f43f3f;
    border-radius: 8px;
}
QLineEdit {
    background-color: #16161b;
    border: 1px solid #2e2e36;
    border-radius: 6px;
    padding: 8px 12px;
    color: #ffffff;
    font-size: 14px;
    selection-background-color: #f43f3f;
}
QLineEdit:focus {
    border: 1px solid #f43f3f;
}
QPushButton {
    background-color: #1e1e24;
    border: 1px solid #2e2e36;
    border-radius: 6px;
    padding: 8px 16px;
    color: #ffffff;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #2b2b34;
    border-color: #3f3f4a;
}
QPushButton#primaryBtn {
    background-color: #b91c1c;
    border: 1px solid #f43f3f;
    color: #ffffff;
    font-size: 14px;
}
QPushButton#primaryBtn:hover {
    background-color: #dc2626;
}
QPushButton#successBtn {
    background-color: #065f46;
    border: 1px solid #10b981;
    color: #ffffff;
}
QPushButton#successBtn:hover {
    background-color: #047857;
}
QTabWidget::pane {
    border: 1px solid #26262b;
    background-color: #111114;
    border-radius: 8px;
    top: -1px;
}
QTabBar::tab {
    background-color: #16161b;
    border: 1px solid #26262b;
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 8px 18px;
    color: #8b8b93;
    font-weight: bold;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #111114;
    color: #f43f3f;
    border-top: 2px solid #f43f3f;
}
QTableWidget {
    background-color: #0d0d10;
    border: 1px solid #1f1f24;
    border-radius: 6px;
    gridline-color: #1a1a20;
    color: #d1d1d6;
}
QHeaderView::section {
    background-color: #16161b;
    color: #9ca3af;
    padding: 6px;
    border: 1px solid #26262b;
    font-weight: bold;
}
QTableWidget::item:selected {
    background-color: #271e22;
    color: #fca5a5;
}
QListWidget {
    background-color: #0d0d10;
    border: 1px solid #1f1f24;
    border-radius: 6px;
    padding: 4px;
    color: #d1d1d6;
}
QListWidget::item {
    padding: 6px 10px;
    border-bottom: 1px solid #16161b;
}
QListWidget::item:hover {
    background-color: #17171d;
    color: #ffffff;
}
QTextEdit {
    background-color: #0d0d10;
    border: 1px solid #1f1f24;
    border-radius: 6px;
    color: #10b981;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
}
QProgressBar {
    border: 1px solid #26262b;
    border-radius: 4px;
    text-align: center;
    background-color: #16161b;
    height: 8px;
}
QProgressBar::chunk {
    background-color: #f43f3f;
}
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("⚡ FiveM CFX Finder & IP Resolver (hex99)")
        self.resize(1180, 820)
        self.setMinimumSize(920, 640)
        self.current_data = None
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        # --- Top Header & Search Bar ---
        top_card = QFrame()
        top_card.setObjectName("card")
        top_layout = QVBoxLayout(top_card)
        top_layout.setContentsMargins(14, 14, 14, 14)
        top_layout.setSpacing(10)

        # Title row
        title_row = QHBoxLayout()
        app_title = QLabel("⚡ FiveM CFX Finder & IP Resolver")
        app_title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        app_title.setStyleSheet("color: #ffffff;")

        badge = QLabel("PRO DESKTOP TOOL")
        badge.setStyleSheet("background-color: #2b1114; color: #f43f3f; border: 1px solid #f43f3f; border-radius: 4px; padding: 2px 8px; font-size: 11px; font-weight: bold;")

        title_row.addWidget(app_title)
        title_row.addWidget(badge)
        title_row.addStretch()
        top_layout.addLayout(title_row)

        # Input Row
        input_row = QHBoxLayout()
        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("Enter CFX Join Link or Code (e.g. cfx.re/join/y4lg95 or y4lg95)...")
        self.code_input.returnPressed.connect(self.start_resolve)

        self.resolve_btn = QPushButton("🔍 RESOLVE SERVER")
        self.resolve_btn.setObjectName("primaryBtn")
        self.resolve_btn.setFixedWidth(180)
        self.resolve_btn.clicked.connect(self.start_resolve)

        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setFixedWidth(70)
        self.clear_btn.clicked.connect(lambda: self.code_input.clear())

        input_row.addWidget(self.code_input)
        input_row.addWidget(self.resolve_btn)
        input_row.addWidget(self.clear_btn)
        top_layout.addLayout(input_row)

        # Status text / progress
        self.status_label = QLabel("Ready. Enter a FiveM CFX code or join link to resolve.")
        self.status_label.setStyleSheet("color: #8b8b93; font-size: 12px;")
        top_layout.addWidget(self.status_label)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setRange(0, 0) # Indeterminate spinner
        top_layout.addWidget(self.progress)

        main_layout.addWidget(top_card)

        # --- Server Hero Card (Direct IP, Status, Hostname) ---
        self.hero_card = QFrame()
        self.hero_card.setObjectName("accentCard")
        hero_layout = QVBoxLayout(self.hero_card)
        hero_layout.setContentsMargins(16, 14, 16, 14)
        hero_layout.setSpacing(10)

        hero_top = QHBoxLayout()
        self.hostname_label = QLabel("No Server Resolved Yet")
        self.hostname_label.setFont(QFont("Segoe UI", 15, QFont.Bold))
        self.hostname_label.setTextFormat(Qt.RichText)
        self.hostname_label.setWordWrap(True)

        self.status_badge = QLabel("OFFLINE")
        self.status_badge.setStyleSheet("background-color: #26262b; color: #9ca3af; border-radius: 4px; padding: 4px 10px; font-weight: bold; font-size: 12px;")

        hero_top.addWidget(self.hostname_label, 1)
        hero_top.addWidget(self.status_badge)
        hero_layout.addLayout(hero_top)

        # Direct IP & Actions Row
        ip_row = QHBoxLayout()
        ip_title = QLabel("DIRECT IP & PORT:")
        ip_title.setStyleSheet("color: #9ca3af; font-size: 12px; font-weight: bold;")

        self.ip_display = QLabel("---.---.---.---:-----")
        self.ip_display.setFont(QFont("Consolas", 14, QFont.Bold))
        self.ip_display.setStyleSheet("color: #10b981; background-color: #0c1a14; border: 1px solid #10b981; border-radius: 4px; padding: 4px 12px;")
        self.ip_display.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.copy_ip_btn = QPushButton("📋 Copy IP:Port")
        self.copy_ip_btn.setObjectName("successBtn")
        self.copy_ip_btn.clicked.connect(self.copy_ip)

        self.connect_fivem_btn = QPushButton("🚀 Join via FiveM")
        self.connect_fivem_btn.clicked.connect(self.launch_fivem)

        self.players_pill = QLabel("👥 0 / 0 Players")
        self.players_pill.setStyleSheet("background-color: #16161b; color: #ffffff; border: 1px solid #2e2e36; border-radius: 4px; padding: 6px 12px; font-weight: bold;")

        ip_row.addWidget(ip_title)
        ip_row.addWidget(self.ip_display)
        ip_row.addWidget(self.copy_ip_btn)
        ip_row.addWidget(self.connect_fivem_btn)
        ip_row.addStretch()
        ip_row.addWidget(self.players_pill)
        hero_layout.addLayout(ip_row)

        main_layout.addWidget(self.hero_card)

        # --- Tabbed Sections ---
        self.tabs = QTabWidget()

        # Tab 1: Overview
        self.tab_overview = QWidget()
        overview_layout = QGridLayout(self.tab_overview)
        overview_layout.setContentsMargins(16, 16, 16, 16)
        overview_layout.setSpacing(12)

        self.info_labels = {}
        fields = [
            ("Game Build:", "gamebuild"),
            ("OneSync:", "onesync"),
            ("Game Type:", "gametype"),
            ("Map Name:", "mapname"),
            ("Server Version:", "server_version"),
            ("Owner:", "owner_name"),
            ("Upvote Power:", "upvote_power"),
            ("Join Link:", "join_url")
        ]
        row, col = 0, 0
        for title, key in fields:
            lbl_title = QLabel(title)
            lbl_title.setStyleSheet("color: #9ca3af; font-weight: bold;")
            lbl_val = QLabel("—")
            lbl_val.setStyleSheet("color: #ffffff; background-color: #16161b; padding: 6px 10px; border-radius: 4px; border: 1px solid #26262b;")
            lbl_val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            overview_layout.addWidget(lbl_title, row, col * 2)
            overview_layout.addWidget(lbl_val, row, col * 2 + 1)
            self.info_labels[key] = lbl_val
            col += 1
            if col > 1:
                col = 0
                row += 1

        self.tabs.addTab(self.tab_overview, "📊 Overview")

        # Tab 2: Players
        self.tab_players = QWidget()
        players_layout = QVBoxLayout(self.tab_players)
        players_layout.setContentsMargins(12, 12, 12, 12)

        p_tools = QHBoxLayout()
        self.player_search = QLineEdit()
        self.player_search.setPlaceholderText("Filter players by name, ID or identifier...")
        self.player_search.textChanged.connect(self.filter_players)

        self.copy_players_btn = QPushButton("Export Player List")
        self.copy_players_btn.clicked.connect(self.export_players)

        p_tools.addWidget(self.player_search)
        p_tools.addWidget(self.copy_players_btn)
        players_layout.addLayout(p_tools)

        self.players_table = QTableWidget()
        self.players_table.setColumnCount(5)
        self.players_table.setHorizontalHeaderLabels(["ID", "Player Name", "Ping", "Discord ID", "Identifiers"])
        self.players_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.players_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        players_layout.addWidget(self.players_table)

        self.tabs.addTab(self.tab_players, "👥 Players")

        # Tab 3: Resources
        self.tab_resources = QWidget()
        res_layout = QVBoxLayout(self.tab_resources)
        res_layout.setContentsMargins(12, 12, 12, 12)

        r_tools = QHBoxLayout()
        self.res_search = QLineEdit()
        self.res_search.setPlaceholderText("Filter resources / scripts...")
        self.res_search.textChanged.connect(self.filter_resources)

        self.res_count_label = QLabel("0 Resources")
        self.res_count_label.setStyleSheet("color: #9ca3af; font-weight: bold;")

        self.copy_res_btn = QPushButton("Copy All Resources")
        self.copy_res_btn.clicked.connect(self.copy_resources)

        r_tools.addWidget(self.res_search)
        r_tools.addWidget(self.res_count_label)
        r_tools.addWidget(self.copy_res_btn)
        res_layout.addLayout(r_tools)

        self.res_list = QListWidget()
        res_layout.addWidget(self.res_list)

        self.tabs.addTab(self.tab_resources, "📦 Resources")

        # Tab 4: Server Convars
        self.tab_convars = QWidget()
        conv_layout = QVBoxLayout(self.tab_convars)
        conv_layout.setContentsMargins(12, 12, 12, 12)

        self.convars_table = QTableWidget()
        self.convars_table.setColumnCount(2)
        self.convars_table.setHorizontalHeaderLabels(["Convar Variable", "Value"])
        self.convars_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.convars_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        conv_layout.addWidget(self.convars_table)

        self.tabs.addTab(self.tab_convars, "⚙️ Convars")

        # Tab 5: Raw JSON
        self.tab_raw = QWidget()
        raw_layout = QVBoxLayout(self.tab_raw)
        raw_layout.setContentsMargins(12, 12, 12, 12)

        raw_tools = QHBoxLayout()
        raw_tools.addStretch()
        self.copy_raw_btn = QPushButton("📋 Copy JSON to Clipboard")
        self.copy_raw_btn.clicked.connect(self.copy_raw)
        raw_tools.addWidget(self.copy_raw_btn)
        raw_layout.addLayout(raw_tools)

        self.raw_text = QTextEdit()
        self.raw_text.setReadOnly(True)
        raw_layout.addWidget(self.raw_text)

        self.tabs.addTab(self.tab_raw, "📄 Raw JSON")

        main_layout.addWidget(self.tabs)

        # Footer
        footer = QLabel("⚡ FiveM CFX Finder & IP Resolver Desktop Tool • Standalone Native Client")
        footer.setStyleSheet("color: #52525b; font-size: 11px;")
        footer.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer)

    def start_resolve(self):
        code = self.code_input.text().strip()
        if not code:
            QMessageBox.warning(self, "Input Required", "Please enter a CFX code or join link.")
            return

        self.resolve_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.status_label.setText(f"Resolving: {code}...")

        self.thread = ResolverThread(code)
        self.thread.status_update.connect(lambda msg: self.status_label.setText(msg))
        self.thread.error.connect(self.on_resolve_error)
        self.thread.finished.connect(self.on_resolve_success)
        self.thread.start()

    def on_resolve_error(self, err_msg):
        self.resolve_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.status_label.setText(f"❌ {err_msg}")
        QMessageBox.critical(self, "Resolution Error", err_msg)

    def on_resolve_success(self, data):
        self.current_data = data
        self.resolve_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.status_label.setText(f"✅ Successfully resolved CFX code: {data['code']}")

        # Hostname & Hero
        html_title = fivem_to_html(data['hostname'])
        self.hostname_label.setText(html_title)

        endpoint = data.get('endpoint') or 'Hidden'
        self.ip_display.setText(endpoint)

        clients = data.get('clients', 0)
        max_clients = data.get('sv_maxclients', 32)
        self.players_pill.setText(f"👥 {clients} / {max_clients} Players")

        self.status_badge.setText("ONLINE")
        self.status_badge.setStyleSheet("background-color: #064e3b; color: #10b981; border: 1px solid #10b981; border-radius: 4px; padding: 4px 10px; font-weight: bold; font-size: 12px;")

        # Overview Tab
        self.info_labels['gamebuild'].setText(str(data.get('gamebuild', 'Default')))
        self.info_labels['onesync'].setText(str(data.get('onesync', 'false')))
        self.info_labels['gametype'].setText(str(data.get('gametype', 'Roleplay')))
        self.info_labels['mapname'].setText(str(data.get('mapname', 'San Andreas')))
        self.info_labels['server_version'].setText(str(data.get('server_version', 'FXServer')))
        self.info_labels['owner_name'].setText(str(data.get('owner_name', 'Unknown')))
        self.info_labels['upvote_power'].setText(str(data.get('upvote_power', 0)))
        self.info_labels['join_url'].setText(f"https://cfx.re/join/{data['code']}")

        # Populate Players Tab
        players = data.get('players', [])
        self.populate_players(players)

        # Populate Resources Tab
        resources = data.get('resources', [])
        self.populate_resources(resources)

        # Populate Convars Tab
        convars = data.get('vars', {})
        self.populate_convars(convars)

        # Populate Raw JSON
        self.raw_text.setPlainText(json.dumps(data.get('raw', {}), indent=2))

    def populate_players(self, players):
        self.players_table.setRowCount(0)
        self.players_table.setRowCount(len(players))
        for row, p in enumerate(players):
            p_id = str(p.get('id', row + 1))
            name = clean_fivem_colors(p.get('name', 'Anonymous'))
            ping = str(p.get('ping', '0'))
            
            # Extract discord / identifiers
            identifiers = p.get('identifiers', [])
            discord_id = "—"
            for ident in identifiers:
                if ident.startswith('discord:'):
                    discord_id = ident.replace('discord:', '')
                    break

            all_ident = ", ".join(identifiers)

            self.players_table.setItem(row, 0, QTableWidgetItem(p_id))
            self.players_table.setItem(row, 1, QTableWidgetItem(name))
            self.players_table.setItem(row, 2, QTableWidgetItem(ping))
            self.players_table.setItem(row, 3, QTableWidgetItem(discord_id))
            self.players_table.setItem(row, 4, QTableWidgetItem(all_ident))

    def filter_players(self, text):
        text = text.lower().strip()
        for row in range(self.players_table.rowCount()):
            match = False
            for col in range(self.players_table.columnCount()):
                item = self.players_table.item(row, col)
                if item and text in item.text().lower():
                    match = True
                    break
            self.players_table.setRowHidden(row, not match)

    def populate_resources(self, resources):
        self.res_list.clear()
        self.res_count_label.setText(f"{len(resources)} Resources Loaded")
        for res in sorted(resources):
            self.res_list.addItem(str(res))

    def filter_resources(self, text):
        text = text.lower().strip()
        for i in range(self.res_list.count()):
            item = self.res_list.item(i)
            item.setHidden(text not in item.text().lower())

    def populate_convars(self, convars):
        self.convars_table.setRowCount(0)
        self.convars_table.setRowCount(len(convars))
        for row, (k, v) in enumerate(sorted(convars.items())):
            self.convars_table.setItem(row, 0, QTableWidgetItem(str(k)))
            self.convars_table.setItem(row, 1, QTableWidgetItem(str(v)))

    def copy_ip(self):
        if self.current_data and self.current_data.get('endpoint'):
            ep = self.current_data['endpoint']
            QApplication.clipboard().setText(ep)
            QMessageBox.information(self, "Copied", f"Copied direct IP to clipboard:\n{ep}")
        else:
            QMessageBox.warning(self, "No IP", "Please resolve a server first.")

    def launch_fivem(self):
        if self.current_data:
            code = self.current_data['code']
            url = QUrl(f"fivem://connect/cfx.re/join/{code}")
            QDesktopServices.openUrl(url)
        else:
            QMessageBox.warning(self, "No Server", "Please resolve a server first.")

    def export_players(self):
        if not self.current_data or not self.current_data.get('players'):
            QMessageBox.warning(self, "No Players", "No player data available to copy.")
            return
        lines = ["ID\tName\tPing\tDiscord"]
        for p in self.current_data['players']:
            p_id = p.get('id', '')
            name = clean_fivem_colors(p.get('name', ''))
            ping = p.get('ping', '')
            discord = ""
            for ident in p.get('identifiers', []):
                if ident.startswith('discord:'):
                    discord = ident
                    break
            lines.append(f"{p_id}\t{name}\t{ping}\t{discord}")
        QApplication.clipboard().setText("\n".join(lines))
        QMessageBox.information(self, "Exported", f"Copied {len(self.current_data['players'])} players to clipboard!")

    def copy_resources(self):
        if not self.current_data or not self.current_data.get('resources'):
            QMessageBox.warning(self, "No Resources", "No resource data available to copy.")
            return
        res_text = "\n".join(self.current_data['resources'])
        QApplication.clipboard().setText(res_text)
        QMessageBox.information(self, "Copied", f"Copied {len(self.current_data['resources'])} resource names to clipboard!")

    def copy_raw(self):
        text = self.raw_text.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Copied", "Copied raw JSON to clipboard!")

def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(DARK_STYLESHEET)
    
    # Try setting window icon
    icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.ico')
    if os.path.isfile(icon_path):
        app.setWindowIcon(QIcon(icon_path))
        
    window = MainWindow()
    if os.path.isfile(icon_path):
        window.setWindowIcon(QIcon(icon_path))
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
